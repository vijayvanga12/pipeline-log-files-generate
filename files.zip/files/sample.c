/*This code gives the  ru-nning pipeline information like pipeline working flow diagram,pipeline stack address .*/
//-----------------------------------------------------------------------------------------------------------------------------------
//adding debugging macro to the file
/*
int setenv(const char *name, const char *value, int overwrite);
--------------------------------------------------------------

name: The name of the environment variable you want to set.
   
value: The value to assign to the environment variable.
   
overwrite: If 0, setenv() will not overwrite an existing environment variable with the same name. If non-zero, it will overwrite it.
-----------------------------------------------------
/export GST_DEBUG_DUMP_DOT_DIR=/path/to/dotfiles
/----------------------------------------------

*/
//----------------------------------------------------------------------------------------------------------------------------------
/*
 Debug Levels: These define the granularity of the debugging information. The levels range from 0 to 9, with increasing verbosity:
-------------
    0 (None): No debug output.
    1 (Error): Only critical errors are logged.
    2 (Warning): Warnings and errors are logged.
    3 (Fixme): Situations where a workaround is used.
    4 (Info): Informational messages about normal operations.
    5 (Debug):(a.out:752417): GStreamer-CRITICAL **: 13:56:20.984: gst_parse_launch_full: assertion 'error == NULL || *error == NULL' failed
failed to create pipeline
 Debugging messages, useful for developers.
    6 (Log): More detailed messages than the debug level.
    7 (Trace): Tracing information, very detailed.
    8 (Memdump): Memory dumps and other detailed data.
    9 (Count): Even more verbose than memdump.
 */
//----------------------------------------------------------------------------------------------------------------------------------

#include<unistd.h>
#include<stdlib.h>
#include <gst/gst.h>
#include<stdio.h>
#include <string.h>

GST_DEBUG_CATEGORY_STATIC (my_category);
#define GST_CAT_DEFAULT my_category

//creating structure to maintain the variable structure order.
typedef struct _CustomData {
  gboolean is_live;
  GstElement *pipeline;
  GMainLoop *loop;
} CustomData;
GstStateChangeReturn ret3,ret2;


//this function gives the stack address and debugging information
static int  my_function(char *str) 
{
  char *trace;
  int c=1;
  GError *error = NULL;
  char cwd[1024];  // Buffer to hold the current working directory
  char log_path[2048];  // Buffer to hold the full log path
  char *str1[]={"1","generated1.log","generated2.log","generated3.log","generated4.log","generated5.log","generated6.log","generated7.log","generated8.log","generated9.log"};   
  char *str2[]={"*:1","*:2","*:3","*:4","*:5","*:6","*:7","*:8","*:9","\0"};  
  for(c;c<6;c++)
    {// Get the current working directory
      if (getcwd(cwd, sizeof(cwd)) != NULL)
      {
 // Construct the full path to the log file
  
        snprintf(log_path, sizeof(log_path), "%s/%s", cwd,str1[c]);

 // Set the GST_DEBUG_FILE environment variable with the full path
        setenv("GST_DEBUG_FILE", log_path, 1);
	printf("\n%s--\n",log_path);
    }
     else
      {
        perror("getcwd() error");
        return -1;
      }
    if(str=="debug.dot")
    {
            return 0;
    }

    /* Set GST_DEBUG environment variable */
  //  setenv("GST_DEBUG","*:1", 1);
    setenv("GST_DEBUG",*(str2+c), 1);
    // ++str2;
    // Enable detailed debug output
    }
   c=0;    


  /* Set GST_DEBUG and GST_DEBUG_FILE environment variables programmatically */
//    setenv("GST_DEBUG", "*:6", 1);  // Set GST_DEBUG level to DEBUG
  //  setenv("GST_DEBUG_FILE", "./gst_debug.log", 1);  // Redirect logs to gst_debug.log

  // Capture the current stack trace
  trace = gst_debug_get_stack_trace(GST_DEBUG_GRAPH_SHOW_ALL);

  // Print the stack trace to the debug log
  if (trace) {
//    gchar *stack_trace_str = gst_debug_stack_trace_to_string(trace);
    g_print("Current stack trace:\n%s", trace);
  //  g_free(stack_trace_str);
  //  gst_debug_stack_trace_free(trace);
  }
}

//adding debugging information to the debug object.
static GstStateChangeReturn  gst_my_element_change_state (GstElement * element, GstStateChange transition)
{
  GstStateChangeReturn ret;

  GST_DEBUG_OBJECT (element, "Changing state from %s to %s",
                    gst_element_state_get_name (GST_STATE_TRANSITION_CURRENT (transition)),
                    gst_element_state_get_name (GST_STATE_TRANSITION_NEXT (transition)));

 // ret = GST_ELEMENT_CLASS (gst_my_element_parent_class)->change_state (element, transition);

  GST_DEBUG_OBJECT (element, "Changed state to %s", gst_element_state_get_name (GST_STATE (element)));

  return ret;
}

//this function gives messages comming from pipeline
static void cb_message (GstBus *bus, GstMessage *msg, CustomData *data) {

  switch (GST_MESSAGE_TYPE (msg)) {
    case GST_MESSAGE_ERROR: {
      GError *err;
      gchar *debug;

      gst_message_parse_error (msg, &err, &debug);
      g_print ("Error: %s\n", err->message);
      g_error_free (err);
      g_free (debug);

      gst_element_set_state (data->pipeline, GST_STATE_READY);
      g_main_loop_quit (data->loop);
      break;
    }
    case GST_MESSAGE_EOS:
      /* end-of-stream */
      gst_element_set_state (data->pipeline, GST_STATE_READY);
      g_main_loop_quit (data->loop);
      break;
    case GST_MESSAGE_BUFFERING: {
      gint percent = 0;

      /* If the stream is live, we do not care about buffering. */
      if (data->is_live) break;

      gst_message_parse_buffering (msg, &percent);
      g_print ("Buffering (%3d%%)\r", percent);
      /* Wait until buffering is complete before start/resume playing */
      if (percent < 100)
        gst_element_set_state (data->pipeline, GST_STATE_PAUSED);
      else
        gst_element_set_state (data->pipeline, GST_STATE_PLAYING);
      break;
    }
    case GST_MESSAGE_CLOCK_LOST:
      /* Get a new clock */
      gst_element_set_state (data->pipeline, GST_STATE_PAUSED);
      gst_element_set_state (data->pipeline, GST_STATE_PLAYING);
      break;
    default:
      /* Unhandled message */
      break;
    }
}


//This is the main function of the file
int main(int argc, char *argv[]) {
  GstElement *pipeline;
  GstBus *bus;
  GstStateChangeReturn ret;
  GMainLoop *main_loop;
  CustomData data;
  GError *err;
  
my_function("generate.log");
  /* Initialize GStreamer */
  gst_init (&argc, &argv);
 //initializing gstreamer debugging information
  /* Initialize our data structure */
  memset (&data, 0, sizeof (data));

  /* Build the pipeline */
 
//  pipeline=gst_parse_launch(" videotestsrc ! autovideosink",&err);
   pipeline = gst_parse_launch ("playbin uri=https://gstreamer.freedesktop.org/data/media/sintel_trailer-480p.webm", NULL);
    //    pipeline = gst_parse_launch ("filesrc location=location=/home/vangav/Videos/video.mp4  ! qtdemux name=demux demux.audio_0 ! queue ! decodebin ! audioconvert ! audioresample ! autoaudiosink demux.video_0  !   queue ! decodebin !  videoconvert !  autovideosink", NULL);

    //pipeline=gst_parse_launch("filesrc location=/home/vangav/Videos/video.mp4 ! qtdemux name=demux demux.audio_0 ! decodebin ! queue ! audioconvert ! autoaudiosink demux.audio_1 ! decodebin ! queue ! audioconvert ! wavescope ! videoconvert ! autovideosink",&err);
    //  pipeline=gst_parse_launch("GST_DEBU=6 v4l2src device=/dev/video0 ! video/x-raw,width=1280,height=720 ! videoconvert  ! autovideosink",&err);
  
  if(pipeline==NULL)
  {
	  printf("failed to create pipeline\n");
	  return -1;
  }
  //getting bus to the pipeline
  bus = gst_element_get_bus (pipeline);

  /* Start playing */
  ret = gst_element_set_state (pipeline, GST_STATE_PLAYING);
  if (ret == GST_STATE_CHANGE_FAILURE) {
    g_printerr ("Unable to set the pipeline to the playing state.\n");
    gst_object_unref (pipeline);
    return -1;
  } else if (ret == GST_STATE_CHANGE_NO_PREROLL) {
    data.is_live = TRUE;
  }
  my_function("debug.dot");
  //macro to get graph from pipeline
 GST_DEBUG_BIN_TO_DOT_FILE(GST_BIN(pipeline), GST_DEBUG_GRAPH_SHOW_ALL, "pipeline-playing");
  ret2= gst_my_element_change_state (pipeline, ret);

  main_loop = g_main_loop_new (NULL, FALSE);
  data.loop = main_loop;
  data.pipeline = pipeline;
  printf("\n-----------%p---pipeline address\n",data.pipeline);

  gst_bus_add_signal_watch (bus);
  g_signal_connect (bus, "message", G_CALLBACK (cb_message), &data);
//  my_function();
  g_main_loop_run (main_loop);

  /* Free resources */
  g_main_loop_unref (main_loop);
  gst_object_unref (bus);
  gst_element_set_state (pipeline, GST_STATE_NULL);
  gst_object_unref (pipeline);
  return 0;
}

